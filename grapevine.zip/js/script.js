$(function() {
    $(".typedContent").typed({
        strings: ["Education.", "Discussion.", "Data.", "Decisions.", "Civic Engagements."],
        typeSpeed: 0
    });
});
